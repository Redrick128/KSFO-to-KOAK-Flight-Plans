This FlightPlan has a Cruising Spd of 250knts and Alt at 3400ft

Aircraft type - A320 | Route - DCT OSI C1173P RAINS C1173O OAK DCT DYBLO (High Level Jet Airways)